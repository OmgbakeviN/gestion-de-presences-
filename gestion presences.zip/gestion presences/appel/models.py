from django.db import models
from django.utils.timezone import now

# Modèle pour les filières
class Filiere(models.Model):
    nom = models.CharField(max_length=100, unique=True)  # Nom unique de la filière

    def __str__(self):
        return self.nom

# Modèle pour les étudiants
class Etudiant(models.Model):
    nom = models.CharField(max_length=100)  # Nom de l'étudiant
    filiere = models.ForeignKey(Filiere, on_delete=models.CASCADE, related_name='etudiants')  # Relation avec la filière
    total_presences = models.PositiveIntegerField(default=0)  # Total des présences
    total_absences = models.PositiveIntegerField(default=0)  # Total des absences

    def __str__(self):
        return self.nom

class Presence(models.Model):
    etudiant = models.ForeignKey('Etudiant', on_delete=models.CASCADE, related_name='presences')
    date = models.DateField(default=now)  # Date de l'appel
    present = models.BooleanField()  # Présent ou absent

    class Meta:
        unique_together = ('etudiant', 'date')  # Empêche les doublons pour un étudiant à une date donnée

    def __str__(self):
        return f"{self.etudiant.nom} - {'Présent' if self.present else 'Absent'} le {self.date}"
