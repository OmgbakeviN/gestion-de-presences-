from django.contrib import admin

# Register your models here.

from django.contrib import admin
from .models import Filiere, Etudiant

@admin.register(Filiere)
class FiliereAdmin(admin.ModelAdmin):
    list_display = ('id', 'nom')

@admin.register(Etudiant)
class EtudiantAdmin(admin.ModelAdmin):
    list_display = ('id', 'nom', 'filiere')
