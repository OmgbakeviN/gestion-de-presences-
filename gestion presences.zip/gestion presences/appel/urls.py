from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Page d'accueil
    path('select-filiere/', views.select_filiere, name='select_filiere'),  # Placeholder pour la suite
    path('login/', views.login_view, name='login'),  # Page de connexion
    path('select-filiere/', views.select_filiere, name='select_filiere'),
    path('mark-attendance/<int:filiere_id>/', views.mark_attendance, name='mark_attendance'),
    path('select-filiere/<int:filiere_id>/save/', views.save_attendance, name='save_attendance'),
    path('filiere/<int:filiere_id>/rapport-mensuel/', views.generate_monthly_pdf, name='generate_monthly_report'),
]
