from django.shortcuts import render, redirect
from django.conf import settings

def home(request):
    # Vérifie si un formulaire est soumis
    if request.method == 'POST':
        password = request.POST.get('password')  # Récupère le mot de passe saisi
        if password == settings.SECRET_PASSWORD:  # Vérifie le mot de passe
            return redirect('select_filiere')  # Redirige si correct
        else:
            return render(request, 'home.html', {'error': 'Mot de passe incorrect'})  # Message d'erreur
    # Affiche la page si aucune donnée n'est soumise
    return render(request, 'home.html')

from .models import Filiere

def select_filiere(request):
    if request.method == 'POST':
        filiere_id = request.POST.get('filiere')  # Récupère l'ID de la filière
        try:
            filiere = Filiere.objects.get(id=filiere_id)
            students = filiere.etudiants.all()  # Liste des étudiants dans cette filière
            return render(request, 'list_students.html', {'filiere': filiere, 'students': students})
        except Filiere.DoesNotExist:
            return render(request, 'select_filiere.html', {'error': 'Filière invalide.', 'filieres': Filiere.objects.all()})
    
    # Affiche la page de sélection de la filière
    return render(request, 'select_filiere.html', {'filieres': Filiere.objects.all()})

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import Filiere

@login_required
def select_filiere(request):
    if request.method == 'POST':
        filiere_id = request.POST.get('filiere')
        try:
            filiere = Filiere.objects.get(id=filiere_id)
            students = filiere.etudiants.all()
            return render(request, 'list_students.html', {'filiere': filiere, 'students': students})
        except Filiere.DoesNotExist:
            return render(request, 'select_filiere.html', {'error': 'Filière invalide.', 'filieres': Filiere.objects.all()})
    
    return render(request, 'select_filiere.html', {'filieres': Filiere.objects.all()})

from django.contrib.auth import authenticate, login
from django.http import HttpResponse

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('select_filiere')  # Redirige vers la sélection de filière
        else:
            return render(request, 'login.html', {'error': 'Identifiant ou mot de passe incorrect.'})
    return render(request, 'login.html')


from .models import Filiere, Etudiant, Presence
from django.utils.timezone import now

def mark_attendance(request, filiere_id):
    filiere = Filiere.objects.get(id=filiere_id)
    if request.method == 'POST':
        for etudiant in filiere.etudiants.all():
            presence_status = request.POST.get(f'present_{etudiant.id}')
            Presence.objects.create(
                etudiant=etudiant,
                date=now().date(),
                present=bool(presence_status)
            )
        return redirect('select_filiere')  # Redirige après l'enregistrement

    students = filiere.etudiants.all()
    return render(request, 'mark_attendance.html', {'filiere': filiere, 'students': students})


from django.db.models import Count, Q

def monthly_report(request):
    filieres = Filiere.objects.all()
    report = []

    for filiere in filieres:
        etudiants = filiere.etudiants.all()
        data = []
        for etudiant in etudiants:
            total_presences = Presence.objects.filter(etudiant=etudiant, present=True).count()
            total_absences = Presence.objects.filter(etudiant=etudiant, present=False).count()
            data.append({
                'etudiant': etudiant,
                'total_presences': total_presences,
                'total_absences': total_absences
            })
        report.append({'filiere': filiere, 'data': data})

    return render(request, 'monthly_report.html', {'report': report})


from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Filiere, Etudiant, Presence
from django.utils.timezone import now

from django.db import IntegrityError

def save_attendance(request, filiere_id):
    filiere = get_object_or_404(Filiere, id=filiere_id)
    students = filiere.etudiants.all()

    if request.method == 'POST':
        for student in students:
            checkbox_name = f'present_{student.id}'
            is_present = checkbox_name in request.POST

            # Vérifie si une présence existe déjà pour l'étudiant à la date d'aujourd'hui
            presence, created = Presence.objects.get_or_create(
                etudiant=student,
                date=now().date(),  # Date du jour
                defaults={'present': is_present}
            )

            if not created:  # Si la présence existe déjà, met à jour la valeur "present"
                presence.present = is_present
                presence.save()

        # Génération automatique du PDF après enregistrement
        return generate_daily_pdf(filiere)

    return HttpResponse("Méthode non autorisée", status=405)


from django.http import HttpResponse
from reportlab.pdfgen import canvas
from .models import Filiere, Etudiant, Presence
from datetime import datetime

from django.db.models import Count, Q

def generate_monthly_pdf(request, filiere_id):
    from io import BytesIO
    from reportlab.pdfgen import canvas
    from django.utils.timezone import now

    try:
        filiere = Filiere.objects.get(id=filiere_id)
    except Filiere.DoesNotExist:
        return HttpResponse("Filière non trouvée.", status=404)

    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    p.setFont("Helvetica", 12)

    # Titre
    p.drawString(200, 800, f"Rapport Mensuel - Filière : {filiere.nom}")
    p.drawString(50, 770, f"Période : {now().strftime('%m/%Y')}")

    # En-têtes
    p.drawString(50, 740, "Nom de l'étudiant")
    p.drawString(300, 740, "Total Présences")
    p.drawString(450, 740, "Total Absences")

    y = 720

    # Calculer les présences et absences
    etudiants = filiere.etudiants.all()
    for etudiant in etudiants:
        total_presences = Presence.objects.filter(
            etudiant=etudiant, 
            present=True, 
            date__month=now().month
        ).count()

        total_absences = Presence.objects.filter(
            etudiant=etudiant, 
            present=False, 
            date__month=now().month
        ).count()

        # Ajout des données dans le PDF
        p.drawString(50, y, etudiant.nom)
        p.drawString(300, y, str(total_presences))
        p.drawString(450, y, str(total_absences))
        y -= 20

        if y < 50:
            p.showPage()
            p.setFont("Helvetica", 12)
            y = 800

    p.save()
    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf')


def generate_daily_pdf(filiere):
    from io import BytesIO
    from reportlab.pdfgen import canvas

    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    p.setFont("Helvetica", 12)

    # Titre
    p.drawString(200, 800, f"Appel du jour - Filière : {filiere.nom}")
    p.drawString(50, 770, f"Date : {now().strftime('%d/%m/%Y')}")

    # En-têtes
    p.drawString(50, 740, "Nom de l'étudiant")
    p.drawString(300, 740, "Présence")

    y = 720
    for student in filiere.etudiants.all():
        try:
            presence = Presence.objects.get(etudiant=student, date=now().date())
            status = "Présent" if presence.present else "Absent"
        except Presence.DoesNotExist:
            status = "Absent"  # Par défaut si aucune présence n'existe

        p.drawString(50, y, student.nom)
        p.drawString(300, y, status)
        y -= 20

        if y < 50:
            p.showPage()
            p.setFont("Helvetica", 12)
            y = 800

    p.save()

    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf')