"""
URL configuration for gestion_presence project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
"""

from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),  # URL pour l'interface d'administration
    path('', include('appel.urls')),  # Inclure les URLs de l'application "appel"
]
